const months = [
    "January", "February", "March", "April",
    "May", "June", "July", "August",
    "September", "October", "November", "December"
];

const weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const calendarLeft = document.querySelector('.calendar-left');
const monthYear = document.getElementById('monthYear');
const daysGrid = document.getElementById('daysGrid');
const eventsDiv = document.getElementById('events');

let currentDate = new Date();

// Add your events here
const events = [   
    { date: new Date(2024, 0, 1), description: 'Happy New Year'}, //jan-0,feb-1,....
    //{date: new Date(YYYY,month-number jan starts is 0 ,date), description: 'Enter text'}
    
    // Add more events as needed
];

// Function to generate calendar grid
function generateCalendarGrid() {
    // Clear existing days in the calendar
    daysGrid.innerHTML = '';

    // Set the month name and year
    monthYear.textContent = `${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`;

    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    const startingDay = firstDayOfMonth.getDay();

    for (let i = 0; i < startingDay; i++) {
        const emptyDay = document.createElement('div');
        emptyDay.classList.add('empty-day');
        daysGrid.appendChild(emptyDay);
    }

    for (let i = 1; i <= lastDayOfMonth.getDate(); i++) {
        const dayDiv = document.createElement('div');
        dayDiv.textContent = i;
        dayDiv.classList.add('date');

        // Check if there's an event on this day
        const event = events.find(e => e.date.getFullYear() === currentDate.getFullYear() && e.date.getMonth() === currentDate.getMonth() && e.date.getDate() === i);
        if (event) {
            // Add a dot to indicate there's an event
            const eventIndicator = document.createElement('span');
            eventIndicator.classList.add('event-indicator');
            dayDiv.appendChild(eventIndicator);

            // Update the click event to show the event description
            dayDiv.addEventListener('click', function () {
                eventsDiv.innerHTML = `<h2>Events</h2><hr><p>${event.description}</p>`;
            });
        } else {
            dayDiv.addEventListener('click', function () {
                eventsDiv.innerHTML = '<h2>Events</h2><hr><p>No events to display</p>';
            });
        }

        daysGrid.appendChild(dayDiv);
    }
}


// Function to display the previous month
function showPreviousMonth() {
    currentDate.setMonth(currentDate.getMonth() - 1);
    generateCalendarGrid();
}

// Function to display the next month
function showNextMonth() {
    currentDate.setMonth(currentDate.getMonth() + 1);
    generateCalendarGrid();
}

// Event listeners for previous and next month buttons
document.getElementById('prevMonth').addEventListener('click', showPreviousMonth);
document.getElementById('nextMonth').addEventListener('click', showNextMonth);

// Generate the calendar grid when the page loads
generateCalendarGrid();

